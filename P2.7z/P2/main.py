name = "Anastasiia"
userName = "Anastasiia"
user_name = "Anastasiia"

# две разные переменные
name = "Anastasiia"
Name = "Anastasiia"

name = "Anastasiia"  # определение переменной name
print(name)  # вывод значения переменной name на консоль
myNumber = input()
print(myNumber)
myAge = input("Введите свой возраст")
print("Ваш возраст", myAge)
isGood=True
print(isGood)   # True

isAlive = False
print(isAlive)  # False
myAge = 69
print("Возраст",myAge)  # Возраст: 69

myCount = 300
print("Количество",myCount)  # Количество: 76

