
a = int(input())
b = int(input())
c = input()
while c!="0":
    if c=="+":
        print(a+b)
    elif c=="-":
        print(a-b)
    elif c=="*":
        print(a*b)
    elif c=="/":
        print(a/b)
    else:
        print("Нет такого действия")
    a = int(input())
    b = int(input())
    c = input()



